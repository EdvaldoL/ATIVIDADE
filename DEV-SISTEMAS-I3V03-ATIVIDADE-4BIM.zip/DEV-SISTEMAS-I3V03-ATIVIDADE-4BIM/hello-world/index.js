alert("Hello world!");
document.write("Hello world!");
console.log("Hello world!");