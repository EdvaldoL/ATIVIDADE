var nome = prompt("Digite seu nome:");
var data = prompt("Digite sua data:");
alert("Seu nome é: " + nome);